package model;

import java.util.Observable;

public class Model extends Observable{
	
	// private fields: 
		// 1. x position of boat 
		// 2. x position of farmer 
		// 3. x position of goose
		// 4. x position of fox
		// 5. x position of beans
	
	
	public void setCharacterPostion () {
		
		// change position of the character 
		
		setChanged() ;
		notifyObservers();
	}
	
	public int getCharacterPostion () {
		// return x position of 
		return 0; 
	}
	
}
