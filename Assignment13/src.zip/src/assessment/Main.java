package assessment;

import view.MainFrame;
import view.Character;
import view.Farmer;
import view.Fox;
import view.Goose;

import java.io.IOException;

import controller.Controller;
import model.Model;
import view.Beans;

public class Main {

	public static void main(String[] args) throws IOException {
		
		Model model = new Model (); 
		
		Controller controller = new Controller(model);
		
		MainFrame mainFrame = new MainFrame(controller, model);
		
		model.addObserver(mainFrame);
		
		Character farmer = new Farmer(50, 100);
		Character fox = new Fox(200,500);
		
		farmer.drawCharacter(mainFrame);
		fox.drawCharacter(mainFrame);
		
		
		
		mainFrame.setVisible(true);
		
		
		
		
	}

}
