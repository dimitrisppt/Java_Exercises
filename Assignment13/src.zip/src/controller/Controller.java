package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import model.Model;

public class Controller implements ActionListener{

	private Model model ;
	
	public Controller (Model model) {
		this.model = model ;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		JButton pressedButton = (JButton) e.getSource();
		System.out.println(pressedButton.getName());
		
		if (pressedButton.getName().equals("Boat Right")){
			
			// 1. check if farmer is on boat 
			// 2. if the farmer is on boat move boat and farmer to right 
			System.out.println("boat and farmer move to the right");
			
			// call setCharacterPostion 
			model.setCharacterPostion(); 

		} else if (pressedButton.getName().equals("Boat Left")){
			// 1. check if farmer is on boat 
			// 2. if the farmer is on boat move boat and farmer to left 
			System.out.println("boat and famrer move to the left");

		} 
		

	}
	
}
