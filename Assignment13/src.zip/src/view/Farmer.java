package view;

import java.io.IOException;

public class Farmer extends Character {
		
	final static String image = "src/Images/farmer.png";
	
	public Farmer(int xPos, int yPos) throws IOException{
		
		super(image, xPos, yPos);
		System.out.println("call super");
	}
	
	

}