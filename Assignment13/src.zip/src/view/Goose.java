package view;

import java.io.IOException;

public class Goose extends Character {
		
	final static String image = "src/Images/goose.png";
	
	public Goose(int xPos, int yPos) throws IOException{
		super(image, xPos, yPos);
	}
	
	

}