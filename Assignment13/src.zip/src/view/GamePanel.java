package view;

import java.awt.Graphics;

import javax.swing.JPanel;

public class GamePanel extends JPanel{
	 private Character character;
	 public GamePanel(Character character) {
		 this.character = character;
	 }
	 protected void paintComponent(Graphics g) {
         super.paintComponent(g);
         g.drawImage(character.image, character.xPos, character.yPos, this);
     }
}
