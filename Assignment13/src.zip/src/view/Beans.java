package view;

import java.io.IOException;

public class Beans extends Character {
		
	final static String image = "src/Images/beans.png";
	
	public Beans(int xPos, int yPos) throws IOException{
		super(image, xPos, yPos);
	}
	
	

}