package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.OverlayLayout;
import javax.swing.SwingConstants;

import controller.Controller;
import model.Model;

public class MainFrame extends JFrame implements Observer{
	
	private Model model ; 
	
	private JPanel left;
	private JPanel right;
	private JPanel center;

	public MainFrame(Controller controller, Model model) throws IOException {
		super("Fox, Goose and Bag of Beans");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.model = model;

		initWidgets(controller);
		
	}
	
	
	public void initWidgets(Controller controller) throws IOException {
		
		JLabel jlBoat = new JLabel("Boat: ", SwingConstants.CENTER);
		JLabel jlFox = new JLabel("Fox: ", SwingConstants.CENTER);
		JLabel jlGoose = new JLabel("Goose: ", SwingConstants.CENTER);
		JLabel jlBeans = new JLabel("Beans: ", SwingConstants.CENTER);
		JLabel jlFarmer = new JLabel("Farmer: ", SwingConstants.CENTER);
		
		// creating the buttons 
		JButton jbBoatLeft = new JButton("<");		
		JButton jbBoatRight = new JButton(">");		
		JButton jbFoxLeft = new JButton("<");				
		JButton jbFoxRight = new JButton(">");			
		JButton jbGooseLeft = new JButton("<");			
		JButton jbGooseRight = new JButton(">");	
		JButton jbBeansLeft = new JButton("<");		
		JButton jbBeansRight = new JButton(">");	
		JButton jbFarmerLeft = new JButton("<");	
		JButton jbFarmerRight = new JButton(">");	
		
		// adding names to the buttons so they could be referenced in the action listener 
		jbBoatLeft.setName("Boat Left");
		jbBoatRight.setName("Boat Right");
		jbFoxLeft.setName("Fox Left");
		jbFoxRight.setName("Fox Right");
		jbGooseLeft.setName("Goose Left");
		jbGooseRight.setName("Goose Right");
		jbBeansLeft.setName("Beans Left");	
		jbBeansRight.setName("Beans Right");
		jbFarmerLeft.setName("Farmer Left");
		jbFarmerRight.setName("Farmer Right");	
		
		// registering the buttons with the controller 
		jbBoatLeft.addActionListener(controller);
		jbBoatRight.addActionListener(controller);
		jbFoxLeft.addActionListener(controller);
		jbFoxRight.addActionListener(controller);
		jbGooseLeft.addActionListener(controller);
		jbGooseRight.addActionListener(controller);
		jbBeansLeft.addActionListener(controller);
		jbBeansRight.addActionListener(controller);
		jbFarmerLeft.addActionListener(controller);
		jbFarmerRight.addActionListener(controller);
		
		ImageIcon imageGrass = new ImageIcon("src/Images/grass2.png");
		ImageIcon imageWater = new ImageIcon("src/Images/water2.png");
				
		// the main frame
		setLayout(new BorderLayout());
		setMinimumSize(new Dimension(600, 300));
		
		// creating the two main panels 
		JPanel jpDisplay = new JPanel(new BorderLayout());
		JPanel jpControls = new JPanel(new GridLayout(1,15));
		
		// the panels that hold the lands and the water
		left = new JPanel (new BorderLayout());
		left.setPreferredSize(new Dimension(180, getHeight()));
		right = new JPanel (new BorderLayout());
		right.setPreferredSize(new Dimension(180, getHeight()));
		center = new JPanel (new BorderLayout());
		
		Fox fox = new Fox(200,200);
		
		
		JLabel leftGrass = new JLabel ();
		imageGrass.getImage();
		JLabel rightGrass = new JLabel ();
		imageGrass.getImage();
		JLabel centerWater = new JLabel();
		// add grass and water images to panels 
		leftGrass.setIcon(imageGrass);
		rightGrass.setIcon(imageGrass);
		centerWater.setIcon(imageWater);
		
		
		
		left.add(leftGrass);
		center.add(centerWater);
		right.add(rightGrass);
		
		
		
		
		
		
		// adding the panels to the display panel 
		jpDisplay.add(left, BorderLayout.WEST);
		jpDisplay.add(right, BorderLayout.EAST);
		jpDisplay.add(center, BorderLayout.CENTER);
		
		// adding all the buttons and labels
		jpControls.add(jlBoat);
		jpControls.add(jbBoatLeft);
		jpControls.add(jbBoatRight);
		jpControls.add(jlFox);
		jpControls.add(jbFoxLeft);
		jpControls.add(jbFoxRight);
		jpControls.add(jlGoose);
		jpControls.add(jbGooseLeft);
		jpControls.add(jbGooseRight);
		jpControls.add(jlBeans);
		jpControls.add(jbBeansLeft);
		jpControls.add(jbBeansRight);
		jpControls.add(jlFarmer);
		jpControls.add(jbFarmerLeft);
		jpControls.add(jbFarmerRight);
		
		// adding the two main panels to the main frame
		add(jpDisplay, BorderLayout.CENTER);
		add(jpControls, BorderLayout.SOUTH);
		

	}
	
	public JPanel getLeftPanel(){
		return left ;
	}
	public JPanel getRightPanel(){
		return right ;
	}
	public JPanel getCenterPanel(){
		return center ;
	}


	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		model.getCharacterPostion(); 
	}
	
	
	
	
	
}
