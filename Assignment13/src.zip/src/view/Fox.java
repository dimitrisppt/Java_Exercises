package view;

import java.io.IOException;

public class Fox extends Character {
		
	final static String image = "src/Images/fox.png";
	
	public Fox(int xPos, int yPos) throws IOException{
		super(image, xPos, yPos);
	}
	
	

}