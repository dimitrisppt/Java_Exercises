package view;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Character extends JFrame{
	int xPos ;
	int yPos ;
	BufferedImage img;
	private String s = ""; 
	BufferedImage image;
	
	public Character (String s, int xPos, int yPos) throws IOException {
		System.out.println("super called");
		this.s = s;
		this.xPos = xPos; 
		this.yPos = yPos;
		this.image = ImageIO.read(new File(s));
	}
	public void drawCharacter (MainFrame frame){
		 
		    GamePanel gamePanel = new GamePanel(this);
	        
	        frame.add (gamePanel);
	        
	}
	
	
	
}
